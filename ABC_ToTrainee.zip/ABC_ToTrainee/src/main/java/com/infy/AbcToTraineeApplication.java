package com.infy;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;

import com.infy.dto.ProjectDTO;
import com.infy.dto.TeamMemberDTO;
import com.infy.service.ProjectService;

@SpringBootApplication
public class AbcToTraineeApplication implements CommandLineRunner {

	public static Log LOGGER = LogFactory.getLog(AbcToTraineeApplication.class);

	@Autowired
	ProjectService projectService;

	@Autowired
	Environment environment;

	public static void main(String[] args) {
		SpringApplication.run(AbcToTraineeApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {

		addProject();
		getProjectDetails();
	}

	public void addProject() {
		List<TeamMemberDTO> l = new ArrayList<TeamMemberDTO>();
		l.add(new TeamMemberDTO());
		l.add(new TeamMemberDTO());
		l.get(0).setDesignation("SSC");
		l.get(1).setDesignation("SSC");
		l.get(0).setEmployeeId(722009);
		l.get(1).setEmployeeId(722019);
		l.get(0).setEmployeeName("Robin");
		l.get(1).setEmployeeName("Monica");
		l.get(0).setSkills("Java, Oracle");
		l.get(1).setSkills("Java, Python");
		ProjectDTO p = new ProjectDTO();
		p.setMemberList(l);
		p.setCost(200000);
		p.setTeamSize(5);
		p.setTechnologyUsed("Java");
		p.setProjectId(5005);
		try {
			projectService.addProject(p);
			LOGGER.info(environment.getProperty("UserInterface.PROJECT_ADDED_SUCCESS") + p.getProjectId());
		} catch (Exception exp) {
			LOGGER.error(environment.getProperty(exp.getMessage()));
		}
	}

	public void getProjectDetails() {
		try {
			var l = projectService.getProjectDetails("Java");
			for (var inx : l) {
				LOGGER.info(inx.toString());
			}
		} catch (Exception exp) {
			LOGGER.error(environment.getProperty(exp.getMessage()));
		}
	}

}