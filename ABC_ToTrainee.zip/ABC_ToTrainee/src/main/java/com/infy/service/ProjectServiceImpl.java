package com.infy.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infy.dto.ProjectDTO;
import com.infy.dto.TeamMemberDTO;
import com.infy.exception.AbcException;
import com.infy.repository.ProjectRepository;
import com.infy.validator.Validator;

@Service(value = "projectService")
public class ProjectServiceImpl implements ProjectService {

	@Autowired
	private ProjectRepository repository;

	@Override
	public Integer addProject(ProjectDTO project) throws AbcException {
		List<TeamMemberDTO> d = project.getMemberList();
		for (TeamMemberDTO e : d) {
			try {
				Validator.validate(e);
			} catch (AbcException exp) {
				throw exp;
			}
		}
		return repository.addProject(project);

	}

	@Override
	public List<ProjectDTO> getProjectDetails(String technology) throws AbcException {
		List<ProjectDTO> l = repository.getProjectDetails().stream()
				.filter((n) -> n.getTechnologyUsed().equals(technology)).collect(Collectors.toList());
		if (l==null || l.isEmpty())
			throw new AbcException("Service.PROJECTS_NOT_FOUND");
		return l;
	}

}
