package com.infy.dto;

public enum ManufacturingUnit {
	U001, U002, U003, U004, U005
}