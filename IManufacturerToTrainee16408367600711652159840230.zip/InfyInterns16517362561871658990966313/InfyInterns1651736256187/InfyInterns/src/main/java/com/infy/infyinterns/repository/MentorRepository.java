package com.infy.infyinterns.repository;

import java.util.List;
//import java.util.Optional;
//import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

import com.infy.infyinterns.entity.Mentor;

//import antlr.collections.List;

public interface MentorRepository extends CrudRepository<Mentor, Integer>
{
	List<Mentor> findByNumberOfProjectsMentored(Integer numberOfProjectsMentored);
//	Optional<Mentor> findByNumberOfProjectsMentored(Integer numberOfProjectsMentored);
	// add methods if required
}
