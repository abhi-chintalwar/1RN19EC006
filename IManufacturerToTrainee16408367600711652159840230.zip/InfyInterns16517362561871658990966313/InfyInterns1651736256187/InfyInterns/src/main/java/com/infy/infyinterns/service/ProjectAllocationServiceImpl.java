package com.infy.infyinterns.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infy.infyinterns.dto.MentorDTO;
import com.infy.infyinterns.dto.ProjectDTO;
import com.infy.infyinterns.entity.Mentor;
import com.infy.infyinterns.entity.Project;
import com.infy.infyinterns.exception.InfyInternException;
import com.infy.infyinterns.repository.MentorRepository;
import com.infy.infyinterns.repository.ProjectRepository;

@Service(value = "projectService")
@Transactional
public class ProjectAllocationServiceImpl implements ProjectAllocationService {
	@Autowired
	private ProjectRepository projectRepository;
	@Autowired
	private MentorRepository mentorRepository;

	@Override
	public Integer allocateProject(ProjectDTO project) throws InfyInternException {
		Optional<Mentor> optional = mentorRepository.findById(project.getMentorDTO().getMentorId());
		// List<MentorDTO>mentorDTOs =new ArrayList<>();
		// if(optional.isEmpty())throw new
		// InfyInternException("Service.Mentor_NOT_FOUND");
		// if(optional.isPresent())
		Mentor mentor = optional.orElseThrow(() -> new InfyInternException("Service.Mentor_NOT_FOUND"));
		if (mentor.getNumberOfProjectsMentored() >= 3)
			throw new InfyInternException("Service.CANNOT_ALLOCATE_PROJECT");
//		ProjectDTO projectDTO = new ProjectDTO();
//		projectDTO.setIdeaOwner(project.getIdeaOwner());
//		projectDTO.setMentorDTO(project.getMentorDTO());
//		projectDTO.setProjectId(project.getProjectId());
//		projectDTO.setProjectName(project.getProjectName());
//		projectDTO.setReleaseDate(project.getReleaseDate());

		Project project1 = new Project();
		project1.setIdeaOwner(project.getIdeaOwner());
		project1.setMentor(mentor);
		project1.setProjectId(project.getProjectId());
		project1.setProjectName(project.getProjectName());
		project1.setReleaseDate(project.getReleaseDate());
		mentor.setNumberOfProjectsMentored(mentor.getNumberOfProjectsMentored() + 1);
		projectRepository.save(project1);
		return project1.getProjectId();
	}

	@Override
	public List<MentorDTO> getMentors(Integer numberOfProjectsMentored) throws InfyInternException {

		List<Mentor> mentors = mentorRepository.findByNumberOfProjectsMentored(numberOfProjectsMentored);
		List<MentorDTO> mentorDTOs = new ArrayList<>();

		if (mentors.isEmpty())
			throw new InfyInternException("Service.MENTOR_NOT_FOUND");
		mentors.forEach(mentor -> {

			MentorDTO mentorDTO = new MentorDTO();
			mentorDTO.setMentorId(mentor.getMentorId());
			mentorDTO.setMentorName(mentor.getMentorName());
			mentorDTO.setNumberOfProjectsMentored(mentor.getNumberOfProjectsMentored());
			mentorDTOs.add(mentorDTO);
		});

		return mentorDTOs;
	}

	@Override
	public void updateProjectMentor(Integer projectId, Integer mentorId) throws InfyInternException {
		Optional<Mentor> optional = mentorRepository.findById(mentorId);
		Mentor mentor = optional.orElseThrow(() -> new InfyInternException("Service.MENTOR_NOT_FOUND"));
		if (mentor.getNumberOfProjectsMentored() >= 3)
			throw new InfyInternException("Service.CANNOT_ALLOCATE_PROJECT");

		Optional<Project> optional1 = projectRepository.findById(projectId);
		Project project = optional1.orElseThrow(() -> new InfyInternException("Service.PROJECT_NOT_FOUND"));
		project.setMentor(mentor);
		mentor.setNumberOfProjectsMentored(mentor.getNumberOfProjectsMentored() + 1);

	}

	@Override
	public void deleteProject(Integer projectId) throws InfyInternException {

		Optional<Project> optional = projectRepository.findById(projectId);
		Project p = optional.orElseThrow(() -> new InfyInternException("Service.PROJECT_NOT_FOUND"));
		if (p.getMentor() == null)
			projectRepository.deleteById(projectId);
		Mentor m = p.getMentor();
		p.setMentor(null);
		projectRepository.deleteById(projectId);
		// m.setnumberOfProjectsMentored(m.getNumberOfProjectsMentored()-1);

		m.setNumberOfProjectsMentored(m.getNumberOfProjectsMentored() - 1);

	}
}