package com.infy.exception;

public class InfyEmployeeException extends Exception {
	private static final long serialVersionUID = 1L;

	public InfyEmployeeException(String message) {
		super(message);
	}
}
