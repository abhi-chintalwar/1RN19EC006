package com.infy.service;

import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infy.dto.EmployeeDTO;
import com.infy.exception.InfyEmployeeException;
import com.infy.repository.EmployeeRepository;
import com.infy.repository.EmployeeRepositoryImpl;
import com.infy.validator.Validator;

@Service(value="employeeService")
@Transactional
public class EmployeeServiceImpl implements EmployeeService {
	@Autowired
	EmployeeRepository repo;

	@Override
	public Integer addEmployee(EmployeeDTO employee) throws InfyEmployeeException {
		Validator.validate(employee);
		EmployeeDTO ret= repo.getEmployeeDetails(employee.getEmployeeId());
		if(ret==null)throw new InfyEmployeeException("Service.EMPLOYEE_ALREADY_PRESENT");
		return repo.addEmployee(employee);
		
		
		//return null;
	}
	
	@Override
	public EmployeeDTO getEmployeeDetails(Integer employeeId) throws InfyEmployeeException {
		return null;
	}
	
	@Override
	public void updateEmployee(Integer employeeId, String emailId) throws InfyEmployeeException {
		

	}
	
	@Override
	public void deleteEmployee(Integer employeeId) throws InfyEmployeeException {

	}
}
