package com.infy;

import java.time.LocalDate;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;

import com.infy.dto.EmployeeDTO;
import com.infy.dto.ManufacturingUnit;
import com.infy.repository.EmployeeRepository;
import com.infy.service.EmployeeServiceImpl;
@SpringBootTest
public class IManufacturerToTraineeApplicationTests {
	@Mock
	private EmployeeRepository employeeRepository;
	@InjectMocks
	private EmployeeServiceImpl employeeServiceImpl = new EmployeeServiceImpl();
	@Test
	public void addEmployeeInvalidEmailId() throws Exception {
		EmployeeDTO employee =new EmployeeDTO();
		employee.setEmailId("abc");
		employee.setDateOfBirth(LocalDate.now());
		employee.setEmployeeId(2001);
		employee.setManufacturingUnit(ManufacturingUnit.U002);
		employee.setName("Jack");
		Mockito.when(employeeRepository.getEmployeeDetails(2001)).thenReturn(employee);
		Exception exception =Assertions.assertThrows(Exception.class, ()->{employeeServiceImpl.addEmployee(employee);});
		Assertions.assertEquals("Validator.INVALID_EMAIL_ID", exception.getMessage());
	}
	@Test
	public void getEmployeeInvalidEmployeeId() throws Exception {
	}
	@Test
	public void updateEmployeeInvalidEmployeeId() throws Exception {
	}
	@Test
	public void deleteEmployeeInvalidEmployeeId() throws Exception {
	}

}
