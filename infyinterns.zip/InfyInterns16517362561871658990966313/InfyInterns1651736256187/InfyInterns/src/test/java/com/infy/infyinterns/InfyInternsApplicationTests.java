package com.infy.infyinterns;

import java.time.LocalDate;
import java.util.Optional;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;

import com.infy.infyinterns.dto.MentorDTO;
import com.infy.infyinterns.dto.ProjectDTO;
import com.infy.infyinterns.entity.Mentor;
import com.infy.infyinterns.repository.MentorRepository;
import com.infy.infyinterns.service.ProjectAllocationService;
import com.infy.infyinterns.service.ProjectAllocationServiceImpl;

@SpringBootTest
public class InfyInternsApplicationTests {

	@Mock
	private MentorRepository mentorRepository;

	@InjectMocks
	private ProjectAllocationService projectAllocationService = new ProjectAllocationServiceImpl();

	@Test
	public void allocateProjectCannotAllocateTest() throws Exception {

		
		ProjectDTO projectDTO = new ProjectDTO();
		projectDTO.setIdeaOwner(10009);
//		projectDTO.setProjectId();
		projectDTO.setProjectName("Android Shopping App");
		projectDTO.setReleaseDate(LocalDate.of(2019, 9, 27));
		
		
		
		MentorDTO mentorDTO =new MentorDTO();
		mentorDTO.setMentorId(1);
		mentorDTO.setMentorName("William");
		mentorDTO.setNumberOfProjectsMentored(4);
		
		projectDTO.setMentorDTO(mentorDTO);

//		
		Mentor ment = new Mentor();
		ment.setMentorId(1);
		ment.setMentorName("William");
		ment.setNumberOfProjectsMentored(4);
		
		
		
		Mockito.when(mentorRepository.findById(1)).thenReturn(Optional.of(ment));
		Exception exception =Assertions.assertThrows(Exception.class, 
				()->projectAllocationService.allocateProject(projectDTO));
		Assertions.assertEquals("Service.CANNOT_ALLOCATE_PROJECT", exception.getMessage());

	}

	@Test
	public void allocateProjectMentorNotFoundTest() throws Exception {
		
		ProjectDTO projectDTO = new ProjectDTO();
		projectDTO.setIdeaOwner(10009);
//		projectDTO.setProjectId();
		projectDTO.setProjectName("Android Shopping App");
		projectDTO.setReleaseDate(LocalDate.of(2019, 9, 27));
		
		
		
		MentorDTO mentorDTO =new MentorDTO();
		mentorDTO.setMentorId(1);
		mentorDTO.setMentorName("William");
		mentorDTO.setNumberOfProjectsMentored(4);
		
		projectDTO.setMentorDTO(mentorDTO);

//		
		Mentor ment = new Mentor();
		ment.setMentorId(1);
		ment.setMentorName("William");
		ment.setNumberOfProjectsMentored(4);
		
	

	}
}